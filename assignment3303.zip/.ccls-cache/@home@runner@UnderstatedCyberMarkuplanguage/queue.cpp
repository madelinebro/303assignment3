#include "function.h"
#include <vector>

// Constructor
template<typename T>
Queue<T>::Queue() : frontNode(nullptr), rearNode(nullptr), queueSize(0) {}

// Destructor
template<typename T>
Queue<T>::~Queue() {
    while (!empty()) {
        pop();
    }
}

// Push operation
template<typename T>
void Queue<T>::push(const T& val) {
    Node* newNode = new Node(val);
    if (empty()) {
        frontNode = rearNode = newNode;
    } else {
        rearNode->next = newNode;
        rearNode = newNode;
    }
    queueSize++;
}

// Pop operation
template<typename T>
void Queue<T>::pop() {
    if (!empty()) {
        Node* temp = frontNode;
        frontNode = frontNode->next;
        delete temp;
        queueSize--;
        if (empty()) {
            rearNode = nullptr;
        }
    }
}

// Get the front element
template<typename T>
T Queue<T>::front() const {
    if (!empty()) {
        return frontNode->data;
    }
    std::cerr << "Queue is empty!\n";
    exit(EXIT_FAILURE);
}

// Get the size of the queue
template<typename T>
size_t Queue<T>::size() const {
    return queueSize;
}

// Check if the queue is empty
template<typename T>
bool Queue<T>::empty() const {
    return queueSize == 0;
}

// Move the front element to the rear
template<typename T>
void Queue<T>::move_to_rear() {
    if (size() < 2) {
        return;
    }

    T frontVal = front();
    pop();
    push(frontVal);
}


template<typename Item_Type>
int linear_search_last_occurrence(const std::vector<Item_Type>& items, const Item_Type& target, size_t pos_last) {
    if (pos_last == 0)
        return -1;

    if (target == items[pos_last - 1])
        return pos_last - 1;
    else
        return linear_search_last_occurrence(items, target, pos_last - 1);
}

void insertion_sort(std::vector<int>& num) {
    int i, j, key;
    for (j = 1; j < num.size(); j++) {
        key = num[j];
        i = j - 1;
        while (i >= 0 && num[i] > key) {
            num[i + 1] = num[i]; 
            i--;
        }
        num[i + 1] = key; 
    }
}
