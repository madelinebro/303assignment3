#include "function.h"

int main() {
  
    Queue<int> myQueue;
    for (int i = 0; i < 110; ++i) {
        myQueue.push(i);
    }

    cout << "Elements in the queue: ";
    while (!myQueue.empty()) {
        cout << myQueue.front() << " ";
        myQueue.pop();
    }
    cout << endl;

    for (int i = 0; i < 10; ++i) {
        myQueue.push(i);
    }

    myQueue.move_to_rear();

    cout << "Elements in the queue after move_to_rear(): ";
    while (!myQueue.empty()) {
        cout << myQueue.front() << " ";
        myQueue.pop();
    }
    cout << endl;

    vector<int> numbers = {1, 2, 3, 4, 5, 3, 2, 1};
    int target = 3;
    int last_occurrence = linear_search_last_occurrence(numbers, target, numbers.size());
    if (last_occurrence != -1) {
        cout << "Last occurrence of " << target << " is at index: " << last_occurrence << endl;
    } else {
        cout << "Target not found in the vector." << endl;
    }
    vector<int> numbers2 = {22, 11, 99, 88, 9, 7, 42};

    cout << "Unsorted list:" << endl;
    for (int num : numbers2) {
        cout << num << " ";
    }
    cout << endl;

    insertion_sort(numbers2);

    cout << "Sorted list:" << endl;
    for (int num : numbers2) {
        cout << num << " ";
    }
    cout << endl;

    return 0;
}