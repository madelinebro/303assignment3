#include <iostream>
#include <vector>

using namespace std;
template<typename T>
class Queue {
protected:
    struct Node {
        T data;
        Node* next;
        Node(T val);
    };

    Node* frontNode;
    Node* rearNode;
    size_t queueSize;

public:
    Queue();
    ~Queue();
    void push(const T& val);
    void pop();
    T front() const;
    size_t size() const;
    bool empty() const;
    void move_to_rear();
};

template<typename Item_Type>
int linear_search_last_occurrence(const vector<Item_Type>& items, const Item_Type& target, size_t pos_last);

void insertion_sort(std::vector<int>& num);